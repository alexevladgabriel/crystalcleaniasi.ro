Enjoy your add-on, be patient.  
I recommend installing  [Typora](https://typora.io/) for the best experience of reading.    
If you run into an issue please contact me.

# Installation

The `assets` folder shouldn't be modified. The folder contains the photos that are used here for a preview.

The `examples` folder is the preview of the files you will edit. If you struggle somewhere, I recommend you review the files from the `examples` folder and compare them with what you have done.

The `screenshots` folder contains how the add-on should look after installation.


## Configuration

<img src="assets/configure_games.png" alt="Installation Guide" title="https://panel.your-awesome-hosting-company.ro/admin/nests" style="zoom:100%;" />
<img src="assets/configure_games2.png" alt="Installation Guide" title="https://panel.your-awesome-hosting-company.ro/admin/nests/view/2" style="zoom:100%;" />

NOTE! : If you are using this module for local environment (local IPs like 127.0.0.1 or localhost), please be sure to add an alias to the allocation IP (that alias need to be a dns or a external ip).

Go to `config/egg_features/query.php`, there are multiple examples made by me,
to help you understand better the structure of the file.

The point `7` `OTHERS Category`, contains the custom query for **(110 games)**.
The remaining categories are the nests id from the panel, with eggs id of the games what to query specified.

```php
    '2' // Represents the source games based on Source Engine (Valve games)
    '2' => [
        '6', // Represents the Ark Survival Evolved - egg id
        '7', // Represents the Counter - Strike : Global Offensive - egg id
        '8', // Represents the Custom Source Engine Game - egg id
        '9', // Represents the Garrys Mod - egg id
        '10', // Represents the Insurgency - egg id
        '11', // Represents the Team Fortress 2 - egg id
        '16', // Represents the Counter-Strike 1.6 (Custom made egg) - egg id
    ],
```

```php
    '7' // Represents the custom category to support all 110 games.
    '7' => [
        // The egg id of teamspeak3 is 13
        '13' => [
            'name' => 'teamspeak3', // The name can be found in SupportedGames.md
            'queryPort' => 10011, // The query port needed to query the specific games/services
        ],
    ],
```

Query name & ports for custom games can be found in the `SupportedGames.md`

## Panel

1. Drag & drop all files from the folder `panel` to `/var/www/pterodactyl`
2. Open `app/Models/Permission.php` and add below `user` array **(redo this step on next panel update)**

```php
'players' => [
        'description' => 'Permissions that control a user\'s ability to view or manage players list/counter',
        'keys' => [
            'view' => 'Allow a user to view all players from the server',
            'kick' => 'Allow a user to kick players from the server',
            'ban' => 'Allow a user to ban players from the server',
            'unban' => 'Allow a user to unban players from the server',
            'op' => 'Allow a user to op players from the server',
            'deop' => 'Allow a user to deop players from the server',
       	],
],
```

<img src="assets/install_permissions.svg" alt="Installation Guide" title="That's how it should appear in your editor" style="zoom:50%;" />


1. Open `routes/api-client.php` and add below **(redo this step on next panel update)**
```php
Route::group(['prefix' => '/settings'], function () {
    Route::post('/rename', [Client\Servers\SettingsController::class, 'rename']);
    Route::post('/reinstall', [Client\Servers\SettingsController::class, 'reinstall']);
    Route::put('/docker-image', [Client\Servers\SettingsController::class, 'dockerImage']);
});
```
the following code snippet:

```php
Route::group(['prefix' => '/players'], function() {
    Route::get('/', [Client\Servers\PlayersController::class, 'index']);
});
```

<img src="assets/install_routes.svg" alt="Installation Guide" title="That's how it should appear in your editor" style="zoom:50%;" />


1. Open `resources/scripts/components/server/console/ServerConsoleContainer.tsx` and add below `import { Alert } from '@/components/elements/alert';` **(redo this step on next panel update)**
```react
import ServerInformation from '@/components/server/players/ServerInformation';
```

5. On the same file search for `<div className={'grid grid-cols-1 md:grid-cols-3 gap-2 sm:gap-4'}>` add above it the following snippet **(redo this step on next panel update)**
```react
<div className={'mb-4'}>
    <Spinner.Suspense>
        <Can action={['players.view']} matchAny>
            <ServerInformation />
        </Can>
    </Spinner.Suspense>
</div>
```

<img src="assets/install_console.svg" alt="ServerConsole.tsx" title="That's how it should appear in your editor" style="zoom:50%;" />

5. I. That's how it should look like.

6. Open `resources/scripts/components/dashboard/ServerRow.tsx` and add below `import isEqual from 'react-fast-compare';` **(redo this step on next panel update)**
```react
import PlayersCounter from "@/components/server/players/PlayersCounter";
```
6. I. On the same file add above of the second `</React.Fragment>`
```react
<PlayersCounter uuid={server.uuid} />
```

7. Open `resources/scripts/routers/routes.ts` and add below `import ServerActivityLogContainer from '@/components/server/ServerActivityLogContainer';` **(redo this step on next panel update)**
```react
import PlayersContainer from '@/components/server/players/PlayersContainer';
```

7. I. On the same file after the following snippet
```json
{
    path: '/activity',
    permission: 'activity.*',
    name: 'Activity',
   	component: ServerActivityLogContainer,
},
```

paste the following:

```react
{
    path: '/players',
    permission: 'players.*',
    name: 'Players',
    component: PlayersContainer,
},
```

<img src="assets/install_router.svg" alt="Installation Guide" title="That's how it should appear in your editor" style="zoom:50%;" />

### SSH - Commands

---

You can check with the command `node -v` to see if you have [**NodeJS**](https://pterodactyl.io/community/customization/panel.html#install-dependencies) installed.  
If you don't have it, follow the below tutorial to install the [**NodeJS**](https://pterodactyl.io/community/customization/panel.html#install-dependencies).  


<img src="assets/install_nodejs.svg" alt="Installation Guide" title="That's commands should be executed depending on your OS" style="zoom:50%;" />

---
**Check PHP Version:**
- `php -v`

<img src="assets/install_php.svg" alt="Installation Guide" title="That's how it should appear in your terminal (putty)" style="zoom:100%;" />

Depending on your **PHP** version installed, you will run the following commands:

**PHP 7.4**
- `apt install php7.4-{bz2,gmp}`

**PHP 8.0**
- `apt install php8.0-{bz2,gmp}`

**PHP 8.1**
- `apt install php8.1-{bz2,gmp}`

---

<img src="assets/install_compiler.svg" alt="Installation Guide" title="Installation guide" style="zoom:50%;" />

1. `cd /var/www/pterodactyl`
2. `composer require scai/php-webrcon:1.0`
3. `composer require austinb/gameq`
4. `composer require xpaw/php-minecraft-query`
5. `composer require xpaw/php-source-query-class`
6. `npm install -g yarn`
7. `yarn install`
8. `yarn build:production`

# Contact
- Discord: **Scai#8477**
- Official Discord Server: **https://discord.gg/aMcPCTJbbr**