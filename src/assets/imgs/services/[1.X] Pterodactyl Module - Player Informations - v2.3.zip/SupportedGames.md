
More information about game ports required to query the server can be found there ([Click me](https://github.com/Austinb/GameQ/wiki/Supported-servers-list-v2))

| Origianl Game Name  | Game Query Name |
| ----- | ---- |
| America's Army 3 | aa3 |
| America's Army: Proving Grounds | aapg |
| ARK: Survival Evolved | arkse |
| ArmA Armed Assault | arma |
| Arma3 | arma3 |
| Armed Assault 2: Operation Arrowhead | armedassault2oa |
| All-Seeing Eye | ase |
| Atlas | atlas |
| Battalion 1944 | batt1944 |
| Battlefield 1942 | bf1942 |
| Battlefield 2 | bf2 |
| Battlefield 3 | bf3 |
| Battlefield 4 | bf4 |
| Battlefield Bad Company 2 | bfbc2 |
| Battlefield Hardline | bfh |
| Brink | brink |
| Call of Duty | cod |
| Call of Duty 2 | cod2 |
| Call of Duty 4 | cod4 |
| Call of Duty: Modern Warfare 3 | codmw3 |
| Call of Duty: United Offensive | coduo |
| Call of Duty: World at War | codwaw |
| Conan Exiles | conanexiles |
| Contagion | contagion |
| Crysis | crysis |
| Crysis 2 | crysis2 |
| Crysis Wars | crysiswars |
| Counter-Strike 1.5 | cs15 |
| Counter-Strike 1.6 | cs16 |
| Counter-Strike 2d | cs2d |
| Counter-Strike: Condition Zero | cscz |
| Counter-Strike: Global Offensive | csgo |
| Counter-Strike: Source | css |
| Dark and Light | dal |
| DayZ Standalone | dayz |
| DayZ Mod | dayzmod |
| Day of Defeat | dod |
| Day of Defeat: Source | dods |
| Days of War | dow |
| ECO Global Survival | eco |
| Empyrion - Galactic Survival | egs |
| Wolfenstein Enemy Territory | et |
| Enemy Territory Quake Wars | etqw |
| Fortress Forever | ffe |
| Frontlines Fuel of War | ffow |
| GameSpy Server | gamespy |
| GameSpy2 Server | gamespy2 |
| GameSpy3 Server | gamespy3 |
| Garry's Mod | gmod |
| GRAV Online | grav |
| GTA Five M | gta5m |
| Grand Theft Auto Network | gtan |
| Half Life 2: Deathmatch | hl2dm |
| Hurtworld | hurtworld |
| Insurgency | insurgency |
| Insurgency: Sandstorm | insurgencysand |
| Star Wars Jedi Knight: Jedi Academy | jediacademy |
| Star Wars Jedi Knight II: Jedi Outcast | jedioutcast |
| Just Cause 2 Multiplayer | justcause2 |
| Just Cause 3 | justcause3 |
| Killing Floor | killing floor |
| Killing Floor 2 | killing floor 2 |
| Left 4 Dead | l4d |
| Left 4 Dead 2 | l4d2 |
| Lost Heaven | lhmp |
| Minecraft | minecraft |
| MinecraftPE | minecraftpe |
| Medal of honor: Allied Assault | mohaa |
| MORDHAU | mordhau |
| Multi Theft Auto | mta |
| Mumble Server | mumble |
| Natural Selection 2 | ns2 |
| PixARK | pixark |
| Project Reality: Battlefield 2 | projectrealitybf2 |
| Quake 2 Server | quake2 |
| Quake 3 Server | quake3 |
| Quake Live | quakelive |
| Red Orchestra 2 | redorchestra2 |
| Red Orchestra: Ostfront 41-45 | redorchestraostfront |
| Rising Storm 2 | rising storm 2 |
| Rust | rust |
| San Andreas Multiplayer | samp |
| Serious Sam | serioussam |
| 7 Days to Die | sevendaystodie |
| The Ship | ship |
| Solder of Fortune II | sof2 |
| Soldat | soldat |
| Source Server | source |
| Space Engineers | spaceengineers |
| Squad | squad |
| StarMade | starmade |
| SWAT 4 | swat4 |
| Teamspeak 2 | teamspeak2 |
| Teamspeak 3 | teamspeak3 |
| Teeworlds Server | teeworlds |
| Terraria | terraria |
| Team Fortress 2 | tf2 |
| The Forrest | theforrest |
| Tibia | tibia |
| Tshock | tshock |
| Unreal 2 | unreal2 |
| Unturned | unturned |
| Urban Terror | urbanterror |
| Unreal Tournament | ut |
| Unreal Tournament 2004 | ut2004 |
| Unreal Tournament 3 | ut3 |
| Ventrilo | ventrilo |
| Warsow | warsow |
| World Opponent Network | won |
| Wurm Unlimited | wurm |