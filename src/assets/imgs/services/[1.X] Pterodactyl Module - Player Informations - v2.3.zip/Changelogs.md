# Version 2.0

## General
- Users can now set the subusers permissions.

## Minecraft (BETA)
- Changed the API website because the old one was suspended. **(The API Website will be used only when the panel can't ping the minecraft server)**

Added features:
- `Deop, Op, Kick, Ban & Unban` players from the server.
- `Bans & Operators` list

## Rust
- New library for querying the RUST Servers. **(The library itself is using the WebRCON of the RUST Server to retrieve the needed informations)**
- `Player List` now fully supported up to **400+ players**

# Version 2.1

## Minecraft
- Improved compability for Minecraft 1.8.8 Servers.

# Version 2.1.1
- Changed library name, for next major update

# Version 2.2
- Updated to latest version of Pterodactyl 1.8.1, new routes.

# Version 2.3

- Updated to latest version of Pterodactyl 1.9.2
- Changed assets, images and examples
- Adapted the UI to the new version of software